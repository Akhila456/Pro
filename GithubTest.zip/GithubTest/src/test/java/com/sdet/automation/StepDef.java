package com.sdet.automation;

import java.awt.AWTException;
import java.io.File;
import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.sdet.core.BaseClass;
import com.sdet.pages.Homepage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDef extends BaseClass {

	Homepage homepage = null;
	String localPath = null;

	@Before
	public void setup() throws AWTException {
		WebDriverManager.chromedriver().setup();
		localPath = System.getProperty("user.dir") + File.separator + "external";
		Map<String, Object> preferences = new Hashtable<String, Object>();
		preferences.put("download.default_directory", localPath);

		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", preferences);
		
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		homepage = new Homepage(driver);
	}

	@Given("^Application is opened using \"([^\"]*)\" and on Home Page$")
	public void openHomePage(String url) {
		driver.get(url);
	}

	@When("^User login using \"([^\"]*)\" and \"([^\"]*)\"$")
	public void searchTV(String username, String password) throws InterruptedException {
		homepage.login(username, password);
	}

	@Then("^verify login is successful$")
	public void verifyLogin() {
		homepage.verifyLoginSuccess();
	}

	@Then("^verify login is unsuccessful$")
	public void verifyInvalidLoginMessage() {
		homepage.verifyInvalidLogin();
	}

	@Then("^verify checkboxes$")
	public void verifyCheckboxes() {
		homepage.verifyCheckbox();
	}

	@Then("^verify context menu$")
	public void verifyContextMenu() throws InterruptedException {
		homepage.verifyContextmenu();
	}

	@Then("^verify drag and drop$")
	public void verifyDragnDrop() throws InterruptedException {
		homepage.verifyDragDrop();
	}

	@Then("^verify dropdown$")
	public void verifyDropDown() {
		homepage.verifyDropAndDown();
	}

	@Then("^verify dynamic content$")
	public void verifyDynamicContent() throws InterruptedException {
		homepage.verifyDynamicText();
	}

	@Then("^verify dynamic controls$")
	public void verifyDynamicControls() {
		homepage.verifyDynamicControls();
	}

	@Then("^verify dynamic loading$")
	public void verifyDynamicload() {
		homepage.verifyDynamicLoading();
	}
	
	@Then("^verify file download$")
	public void verifyDownload() throws InterruptedException {
		homepage.verifyFileDownload(localPath);
	}
	
	@Then("^verify file upload$")
	public void verifyUpload() throws InterruptedException {
		homepage.verifyUpload(localPath + File.separator + "some-file.txt");
	}
	
	@Then("^verify floating menu$")
	public void verifyFloatingMenu() throws InterruptedException {
		homepage.verifyFloatingMenu();
	}
	
	@Then("^verify frames$")
	public void verifyFrames() throws InterruptedException {
		homepage.verifyFrames();
	}
	
	@Then("^verify mouse hover$")
	public void verifyMouseHover() throws InterruptedException {
		homepage.verifyMouseHover();
	}
	
	@Then("^verify javascript alerts$")
	public void verifyJSAlerts()  {
		homepage.verifyJSAlerts();
	}
	
	@Then("^verify javascript error$")
	public void verifyJSError() throws InterruptedException {
		homepage.verifyJSError();
	}
	
	@Then("^verify new window$")
	public void verifyNewWindow() throws InterruptedException {
		homepage.verifyNewWindow();
	}
	
	@Then("^verify notifications$")
	public void verifyNotifications() throws InterruptedException {
		homepage.verifyNotifications();
	}
	
	@After
	public void tearDown() {
		driver.close();
		driver.quit();
	}
}
